const $hamburger = $('<a href="#" class="btn btn-hamburger"><i class="fa-solid fa-bars"></i></a>');


$(document).ready(function() {
    $hamburger.insertBefore('.navbar.collapsable');
    $('.navbar.collapsable').on('click', function() {
        $(this).css('display','none');
    })
    $('.btn-hamburger').on('click', function() {
        $navbar = $(this).parent().find('.navbar.collapsable');

        if($navbar.css('display') === 'none') {
            $navbar.css('display','block');
        } else {
            $navbar.css('display','none');
        }       
    })
})