$(document).ready(function() {
    $('#main-home').css('display','flex');

    $('#nav-home').on('click',function() {
        if($('#main-home').css('display') !== 'flex') {
            $('.body-text').css('display','none');
            $('#main-home').css('display','flex');
        }
    })
    $('#nav-sequence').on('click',function() {
        if($('#main-sequence').css('display') !== 'flex') {
            $('.body-text').css('display','none');
            $('#main-sequence').css('display','flex');
        }
    })
    $('#nav-location').on('click',function() {
        if($('#main-location').css('display') !== 'flex') {
            $('.body-text').css('display','none');
            $('#main-location').css('display','flex');
        }
    })
    $('#nav-dress').on('click',function() {
        if($('#main-dress').css('display') !== 'flex') {
            $('.body-text').css('display','none');
            $('#main-dress').css('display','flex');
        }
    })
})